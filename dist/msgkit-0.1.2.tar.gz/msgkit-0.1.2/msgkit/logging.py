from msgkit import errorlog

logger = errorlog.ErrorLog()